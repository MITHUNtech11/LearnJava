package leetcodes;
public class ArrayMinMax {

    // Function to find minimum
    static int findMin(int arr[]) {
        int min = arr[0];

        for(int i = 1; i < arr.length; i++) {
            if(arr[i] < min) {
                min = arr[i];
            }
        }

        return min;
    }

    // Function to find maximum
    static int findMax(int arr[]) {
        int max = arr[0];

        for(int i = 1; i < arr.length; i++) {
            if(arr[i] > max) {
                max = arr[i];
            }
        }

        return max;
    }

    public static void main(String[] args) {

        int arr1[] = {0};
        int arr2[] = {8, 2, 19, 4, 12};

        System.out.println("Array 1:");
        System.out.println("Minimum element: " + findMin(arr1));
        System.out.println("Maximum element: " + findMax(arr1));

        System.out.println();

        System.out.println("Array 2:");
        System.out.println("Minimum element: " + findMin(arr2));
        System.out.println("Maximum element: " + findMax(arr2));
    }
}