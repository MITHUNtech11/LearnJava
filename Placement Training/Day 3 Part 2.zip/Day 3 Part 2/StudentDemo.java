package leetcodes;
class Student {

    // Private data members
    private int rollNo;
    private String name;
    private int m1, m2;
    private int total;
    private char grade;

    // Setter method
    public void setData(int r, String n, int a, int b) {
        rollNo = r;
        name = n;
        m1 = a;
        m2 = b;
    }

    // Method to calculate total and grade
    public void calculate() {
        total = m1 + m2;
        int avg = total / 2;

        if (avg >= 80)
            grade = 'A';
        else if (avg >= 60)
            grade = 'B';
        else if (avg >= 50)
            grade = 'C';
        else
            grade = 'F';
    }

    // Getter methods
    public int getRollNo() {
        return rollNo;
    }

    public String getName() {
        return name;
    }

    public int getTotal() {
        return total;
    }

    public char getGrade() {
        return grade;
    }
}

public class StudentDemo {

    static void displayStudent(Student s) {

        System.out.println("Student Details");
        System.out.println("Roll No: " + s.getRollNo());
        System.out.println("Name: " + s.getName());
        System.out.println("Total Marks: " + s.getTotal());
        System.out.println("Grade: " + s.getGrade());
    }

    public static void main(String args[]) {

        Student s1 = new Student();

        s1.setData(101, "Rahul", 85, 70);
        s1.calculate();

        displayStudent(s1);
    }
}