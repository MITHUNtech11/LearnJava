import React, { useState, useEffect } from 'react';
import { Play, RotateCcw, SkipForward, Code } from 'lucide-react';

export default function EuclideanGCD() {
  const [a, setA] = useState(48);
  const [b, setB] = useState(18);
  const [steps, setSteps] = useState([]);
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showCode, setShowCode] = useState(true);

  const javaCodeIterative = `public class GCDEuclidean {
    
    // Iterative approach
    public static int gcdIterative(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
    
    // Example usage
    public static void main(String[] args) {
        int num1 = 48;
        int num2 = 18;
        
        int result = gcdIterative(num1, num2);
        System.out.println("GCD of " + num1 + 
                         " and " + num2 + " = " + result);
        // Output: GCD of 48 and 18 = 6
    }
}`;

  const javaCodeRecursive = `public class GCDEuclidean {
    
    // Recursive approach
    public static int gcdRecursive(int a, int b) {
        if (b == 0) {
            return a;  // Base case
        }
        return gcdRecursive(b, a % b);
    }
    
    // Example usage
    public static void main(String[] args) {
        int num1 = 48;
        int num2 = 18;
        
        int result = gcdRecursive(num1, num2);
        System.out.println("GCD of " + num1 + 
                         " and " + num2 + " = " + result);
        // Output: GCD of 48 and 18 = 6
    }
}`;

  const calculateSteps = (num1, num2) => {
    const newSteps = [];
    let a = Math.abs(num1);
    let b = Math.abs(num2);
    
    if (a < b) [a, b] = [b, a];
    
    newSteps.push({
      a, b,
      operation: 'Initial values',
      remainder: null,
      quotient: null
    });

    while (b !== 0) {
      const quotient = Math.floor(a / b);
      const remainder = a % b;
      
      newSteps.push({
        a, b,
        operation: `${a} = ${b} × ${quotient} + ${remainder}`,
        remainder,
        quotient
      });
      
      a = b;
      b = remainder;
    }
    
    newSteps.push({
      a, b: 0,
      operation: `GCD found: ${a}`,
      remainder: null,
      quotient: null,
      isFinal: true
    });
    
    return newSteps;
  };

  useEffect(() => {
    const newSteps = calculateSteps(a, b);
    setSteps(newSteps);
    setCurrentStep(0);
    setIsPlaying(false);
  }, [a, b]);

  useEffect(() => {
    let timer;
    if (isPlaying && currentStep < steps.length - 1) {
      timer = setTimeout(() => {
        setCurrentStep(prev => prev + 1);
      }, 1500);
    } else if (currentStep >= steps.length - 1) {
      setIsPlaying(false);
    }
    return () => clearTimeout(timer);
  }, [isPlaying, currentStep, steps.length]);

  const reset = () => {
    setCurrentStep(0);
    setIsPlaying(false);
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const VisualBlock = ({ value, label, highlight }) => (
    <div className={`flex flex-col items-center p-4 rounded-lg border-2 transition-all ${
      highlight ? 'border-blue-500 bg-blue-50 scale-105' : 'border-gray-300 bg-white'
    }`}>
      <div className={`text-3xl font-bold ${highlight ? 'text-blue-600' : 'text-gray-800'}`}>
        {value}
      </div>
      <div className="text-sm text-gray-600 mt-1">{label}</div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-2 text-gray-800">
          Euclidean Algorithm for GCD
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Visual demonstration and Java implementation
        </p>

        {/* Input Section */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                First Number (a)
              </label>
              <input
                type="number"
                value={a}
                onChange={(e) => setA(parseInt(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Second Number (b)
              </label>
              <input
                type="number"
                value={b}
                onChange={(e) => setB(parseInt(e.target.value) || 0)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Play size={18} />
              {isPlaying ? 'Pause' : 'Play'}
            </button>
            <button
              onClick={nextStep}
              disabled={currentStep >= steps.length - 1}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400"
            >
              <SkipForward size={18} />
              Next Step
            </button>
            <button
              onClick={reset}
              className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
            >
              <RotateCcw size={18} />
              Reset
            </button>
          </div>
        </div>

        {/* Visualization Section */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-2xl font-bold mb-4 text-gray-800">Visual Steps</h2>
          
          {steps.length > 0 && (
            <div className="space-y-4">
              <div className="flex justify-center items-center gap-8">
                <VisualBlock 
                  value={steps[currentStep].a} 
                  label="a" 
                  highlight={!steps[currentStep].isFinal}
                />
                <div className="text-2xl text-gray-400">÷</div>
                <VisualBlock 
                  value={steps[currentStep].b} 
                  label="b" 
                  highlight={!steps[currentStep].isFinal}
                />
                {steps[currentStep].remainder !== null && (
                  <>
                    <div className="text-2xl text-gray-400">=</div>
                    <VisualBlock 
                      value={steps[currentStep].remainder} 
                      label="remainder" 
                      highlight={true}
                    />
                  </>
                )}
              </div>

              <div className={`p-4 rounded-lg text-center text-lg font-medium ${
                steps[currentStep].isFinal 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-blue-100 text-blue-800'
              }`}>
                {steps[currentStep].operation}
              </div>

              {/* Progress Indicator */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">
                  Step {currentStep + 1} of {steps.length}
                </span>
                <div className="flex-1 bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all"
                    style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Algorithm Explanation */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-2xl font-bold mb-4 text-gray-800">How It Works</h2>
          <div className="space-y-3 text-gray-700">
            <p className="flex items-start gap-2">
              <span className="font-bold text-blue-600">1.</span>
              <span>Divide the larger number (a) by the smaller number (b)</span>
            </p>
            <p className="flex items-start gap-2">
              <span className="font-bold text-blue-600">2.</span>
              <span>Find the remainder (r = a % b)</span>
            </p>
            <p className="flex items-start gap-2">
              <span className="font-bold text-blue-600">3.</span>
              <span>Replace a with b, and b with r</span>
            </p>
            <p className="flex items-start gap-2">
              <span className="font-bold text-blue-600">4.</span>
              <span>Repeat until b becomes 0</span>
            </p>
            <p className="flex items-start gap-2">
              <span className="font-bold text-blue-600">5.</span>
              <span>The GCD is the final value of a</span>
            </p>
          </div>
        </div>

        {/* Code Section */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-800">Java Implementation</h2>
            <button
              onClick={() => setShowCode(!showCode)}
              className="flex items-center gap-2 px-3 py-1 text-sm bg-gray-200 rounded-lg hover:bg-gray-300"
            >
              <Code size={16} />
              {showCode ? 'Hide Code' : 'Show Code'}
            </button>
          </div>

          {showCode && (
            <div className="space-y-4">
              <div>
                <h3 className="text-lg font-semibold mb-2 text-gray-700">Iterative Approach</h3>
                <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                  <code>{javaCodeIterative}</code>
                </pre>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-2 text-gray-700">Recursive Approach</h3>
                <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                  <code>{javaCodeRecursive}</code>
                </pre>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <h4 className="font-semibold text-blue-900 mb-2">Time Complexity</h4>
                <p className="text-blue-800 text-sm">
                  O(log min(a, b)) - The algorithm is very efficient, even for large numbers
                </p>
              </div>

              <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                <h4 className="font-semibold text-green-900 mb-2">Space Complexity</h4>
                <p className="text-green-800 text-sm">
                  Iterative: O(1) | Recursive: O(log min(a, b)) due to call stack
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
